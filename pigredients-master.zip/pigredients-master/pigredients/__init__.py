# Pigredients

__version__ = '0.5'
__author__ = 'Chris Fane'
__license__ = 'MIT'
